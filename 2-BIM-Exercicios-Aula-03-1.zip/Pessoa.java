public class Pessoa {
  
  private String nome;
  private int idade;
  private String endereco;
  private int cep;
  private String nomePai;
  private String nomeMae;

  public void setNome(String novoNome){ 
    nome = novoNome; 
  }

  public String getNome(){
    return nome;
  }

  public void setIdade(int novoIdade){
    idade = novoIdade;
  }

  public int getIdade(){
    return idade;
  }

  public void setEndereco(String novoEndereco){
    endereco = novoEndereco;
  }

  public String getEndereco(){
    return endereco;
  }
}