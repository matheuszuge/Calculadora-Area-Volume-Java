public class Main {

  public static void main(String[] args) {

    Pessoa p = new Pessoa();
    p.setNome("Matheus");
    System.out.println("Nome: " +p.getNome());
    p.setIdade(21);
    System.out.println("Idade: " +p.getIdade());
    p.setEndereco("Rua das palmeiras n0");
    System.out.println("Endereço: " +p.getEndereco());

  }
}